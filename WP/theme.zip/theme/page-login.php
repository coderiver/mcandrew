<?php
/*
Template Name: Login page
*/
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
get_header(); ?>

<!-- in -->
<div class="in in_pt145">
	<!-- center -->
	<div class="center">
		<!-- content -->
		<div class="content">
			<?php
			// load content
			if (have_posts()) :
			   while (have_posts()) :
			      the_post();
			         the_content();
			   endwhile;
			endif;
			?>
		</div>
		<!-- login -->
		<div class="login">
			<div class="login__item">
				<!-- form -->
				<div class="form">
					<div class="form__title"><span>Agents Login</span></div>
					<!-- field -->
					<div class="field">
						<input class="input" type="text" placeholder="User Name">
					</div>
					<!-- field -->
					<div class="field">
						<input class="input" type="text" placeholder="Password">
					</div>
					<!-- field -->
					<div class="field">
						<button class="btn">login</button>
					</div>
					<!-- field -->
					<div class="field field_mb0">
						<a href="#">Forgot Password</a>
					</div>
				</div>
			</div>
			<div class="login__item">
				<!-- form -->
				<div class="form">
					<div class="form__title"><span>TENANTS / OWNERS Login</span></div>
					<!-- field -->
					<div class="field">
						<input class="input" type="text" placeholder="User Name">
					</div>
					<!-- field -->
					<div class="field">
						<input class="input" type="text" placeholder="Password">
					</div>
					<!-- field -->
					<div class="field">
						<button class="btn">login</button>
					</div>
					<!-- field -->
					<div class="field field_mb0">
						<a href="#">Forgot Password</a>
					</div>
				</div>
			</div>
			<div class="login__item login__item_wide">
				<!-- form -->
				<div class="form">
					<div class="form__title"><span>SIGN UP TO THE McANDREW NETWORK</span></div>
					<!-- fieldset -->
					<div class="fieldset fieldset_row">
						<!-- field -->
						<div class="field">
							<input class="input" type="text" placeholder="User Name">
						</div>
						<!-- field -->
						<div class="field">
							<input class="input" type="text" placeholder="Password">
						</div>
						<!-- field -->
						<div class="field">
							<div class="field__label">I’m an:</div>
							<div class="field__in">
								<!-- select -->
								<div class="select js-select">
									<div class="select__head">AGENT</div>
									<select name="" id="">
										<option value="AGENT">AGENT</option>
										<option value="AGENT SMITH">AGENT SMITH</option>
										<option value="AGENT 777, BOND, JAMES BOND">AGENT BOND, JAMES BOND</option>
										<option value="AGENT3">AGENT3</option>
										<option value="AGENT4">AGENT4</option>
									</select>
								</div>
							</div>
						</div>
						<!-- field -->
						<div class="field field_w85px">
							<button class="btn">SIGN UP</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
