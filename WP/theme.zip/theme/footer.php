<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

	<!-- footer -->
	<footer class="footer">
		<!-- center -->
		<div class="center l">
			<div class="footer__left">
				<a class="footer__logo" href="/"></a>
				<nav class="footer__nav">
					<ul>
						<li><a href="#">Home</a></li>
						<li><a href="#">Login</a></li>
						<li><a href="#">Privacy Statement</a></li>
					</ul>
					<ul>
						<li><a href="#">Sales</a></li>
						<li><a href="#">Residential</a></li>
						<li><a href="#">News</a></li>
					</ul>
					<ul>
						<li><a href="#">Rental</a></li>
						<li><a href="#">Rent</a></li>
						<li><a href="#">Tenants & Landlords</a></li>
					</ul>
					<ul>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Our Story</a></li>
						<li><a href="#">Our People</a></li>
						<li><a href="#">Our Services</a></li>
						<li><a href="#">FAQ’s</a></li>
					</ul>
				</nav>
			</div>
			<div class="footer__right">
				<div class="footer__form">
					<div class="title title_2">Contact Us</div>
					<!-- form -->
					<div class="form">
						<!-- field -->
						<div class="field">
							<input class="input" type="text" placeholder="Name">
						</div>
						<!-- field -->
						<div class="field">
							<input class="input" type="text" placeholder="Email">
						</div>
						<!-- fieldset -->
						<div class="fieldset">
							<!-- field -->
							<div class="field field_w60">
								<input class="input" type="text" placeholder="Phone">
							</div>
							<!-- field -->
							<div class="field field_w40">
								<input class="input" type="text" placeholder="Postcode">
							</div>
						</div>
						<!-- field -->
						<div class="field">
							<textarea class="textarea" placeholder="Message"></textarea>
						</div>
						<!-- field -->
						<div class="field field_right">
							<button class="btn">SEND</button>
						</div>
					</div>
				</div>
			</div>
			<!-- social -->
			<div class="social">
				<a class="social__fb" href="#"></a>
				<a class="social__tw" href="#"></a>
				<a class="social__in" href="#"></a>
			</div>
		</div>
	</footer>
	<!-- border -->
	<div class="border border_top"></div>
	<div class="border border_bottom"></div>
</div>
<!-- load scripts -->
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/head.js"></script>
<script>
	head.load("<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/jquery.js", 
			  "<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/slick.min.js",
			  "<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/lightbox.min.js",
			  "<?php echo esc_url( get_template_directory_uri() ); ?>/js/common.js");
</script>
</body>
</html>
