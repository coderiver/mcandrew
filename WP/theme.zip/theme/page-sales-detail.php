<?php
/*
Template Name: Sales detail page
*/
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
get_header(); ?>

<!-- in -->
<div class="in">
	<!-- sl -->
	<div class="sl">
		<div class="sl__in js-sl">
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl1.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl2.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl3.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl4.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl5.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl6.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl7.jpg)"></div>
		</div>
	</div>
	<!-- center -->
	<div class="center">
		<!-- project -->
		<div class="project">
			<div class="project__cell">
				<img src="http://placehold.it/280x150" alt="">
			</div>
			<div class="project__cell">
				<!-- h -->
				<div class="h">&lt;Project Name&gt;</div>
				<div class="h h_2 h_gray h_mb0">123 Address St, Goes here, Qld 1234</div>
			</div>
		</div>
		<!-- slider -->
		<div class="slider js-slider">
			<div class="slider__item"><img src="http://placehold.it/900x370" alt=""></div>
			<div class="slider__item"><img src="http://placehold.it/900x370" alt=""></div>
			<div class="slider__item"><img src="http://placehold.it/900x370" alt=""></div>
			<div class="slider__item"><img src="http://placehold.it/900x370" alt=""></div>
			<div class="slider__item"><img src="http://placehold.it/900x370" alt=""></div>
		</div>
		<!-- l -->
		<div class="l l_section">
			<div class="col col_w590">
				<!-- title -->
				<div class="title title_big">Small headline goes here</div>
				<!-- content -->
				<div class="content">
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.  Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.  Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia m ipsum dolor sit amet,  tempor incididunt ut labore et dolore magna aliqua. </p>
				</div>
				<!-- btn-group -->
				<div class="btn-group">
					<button class="btn btn_w130">visit website</button>
				</div>
				<!-- title -->
				<div class="title">Download Marketing Collateral</div>
				<!-- download -->
				<div class="download">
					<a href="#">AERIALS</a>
					<a href="#">ebook</a>
					<a href="#">floor plates</a>
					<a href="#">floor plans</a>
					<a href="#">information memorandum</a>
					<a href="#">logo</a>
					<a href="#">map</a>
					<a href="#">price list</a>
					<a href="#">renders</a>
					<a href="#">schedule of finishes</a>
				</div>
				<!-- btn-group -->
				<div class="btn-group">
					<button class="btn btn_w130">log OUT</button>
				</div>
			</div>
			<div class="col col_w280">
				<!-- title -->
				<div class="title title_big">Agent/s</div>
				<!-- agent -->
				<div class="agent">
					<div class="agent__ava">
						<img src="http://lorempixel.com/80/80/people/" alt="">
					</div>
					<div class="agent__in">
						<!-- title -->
						<div class="title title_3">Agents Name</div>
						<dl class="agent__info">
						  	<dt>P</dt>
						   	<dd>1234 5678</dd>
						</dl>
						<dl class="agent__info">
						  	<dt>M</dt>
						   	<dd>0412 345 678</dd>
						</dl>
					</div>
				</div>
				<!-- btn-group -->
				<div class="btn-group">
					<button class="btn">view inspection times</button>
				</div>
				<!-- title -->
				<div class="title title_2">Contact Agent</div>
				<!-- form -->
				<div class="form">
					<!-- field -->
					<div class="field">
						<input class="input" type="text" placeholder="Name">
					</div>
					<!-- field -->
					<div class="field">
						<input class="input" type="text" placeholder="Email">
					</div>
					<!-- fieldset -->
					<div class="fieldset">
						<!-- field -->
						<div class="field field_w60">
							<input class="input" type="text" placeholder="Phone">
						</div>
						<!-- field -->
						<div class="field field_w40">
							<input class="input" type="text" placeholder="Postcode">
						</div>
					</div>
					<!-- field -->
					<div class="field">
						<!-- check -->
						<label class="check">
							<input type="checkbox">
							<span class="check__in">Send me an information pack</span>
						</label>
						<!-- check -->
						<label class="check">
							<input type="checkbox">
							<span class="check__in">Send me a brochure</span>
						</label>
						<!-- check -->
						<label class="check">
							<input type="checkbox">
							<span class="check__in">Request an appointment</span>
						</label>
					</div>
					<!-- field -->
					<div class="field">
						<textarea class="textarea" placeholder="Message"></textarea>
					</div>
					<!-- field -->
					<div class="field field_right">
						<button class="btn">SEND</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
