<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/lightbox.css" type="text/css" media="all">
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
	<script>(function(){document.documentElement.className='js'})();</script>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<!-- wrap -->
<div class="wrap">
	<!-- header -->
	<header class="header">
		<!-- center -->
		<div class="center l">
			<a class="header__logo" href="/"></a>
			<div class="header__right">
				<ul class="header__contacts">
					<li><a href="tel:+61732668555"><i class="icon icon-phone"></i><span>+61 (7) 3266 8555</span></a></li>
					<li><a href="mailto:bob@google.com"><i class="icon icon-mail"></i><span>CONTACT US</span></a></li>
				</ul>
				<button class="btn-nav js-btn-nav"></button>
				<!-- nav -->
				<div class="nav js-nav">
					<?php
						$defaults = array(
							'theme_location'  => '',
							'menu'            => 'Header menu',
							'container'       => false,
							'container_class' => '',
							'container_id'    => '',
							'menu_class'      => 'nav__list',
							'menu_id'         => '',
							'echo'            => true,
							'fallback_cb'     => 'wp_page_menu',
							'before'          => '',
							'after'           => '',
							'link_before'     => '',
							'link_after'      => '',
							'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
							'depth'           => 0,
							'walker'          => ''
						);
						wp_nav_menu( $defaults );
					?>

				</div>
			</div>
		</div>
	</header>
		

