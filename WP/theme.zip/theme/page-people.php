<?php
/*
Template Name: People page
*/
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
get_header(); ?>

<!-- in -->
<div class="in">
	<!-- sl -->
	<div class="sl sl_mb0">
		<div class="sl__in js-sl">
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl1.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl2.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl3.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl4.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl5.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl6.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl7.jpg)"></div>
		</div>
	</div>
	<!-- bg -->
	<div class="bg">
		<div class="bg__in js-bg"></div>
		<!-- center -->
		<div class="center">
			<!-- l -->
			<div class="l l_section js-f-wrap">
				<div class="col col_w150">
					<!-- js class for fixed column -->
					<div class="js-f-col">
						<!-- btn-menu -->
						<button class="btn-menu js-btn-menu">
							<i></i>
							<span>Menu</span>
						</button>
						<!-- menu -->
						<ul class="menu js-menu">
							<li class="is-active"><a href="#">OUR MISSION</a></li>
							<li><a href="#">OUR TEAM</a></li>
							<li><a href="#">INDUSTRY PARTNERS</a></li>
							<li><a href="#">OVERVIEW OF WORKING RELATIONSHIPS</a></li>
							<li><a href="#">OUR EXPERIENCE</a></li>
							<li><a href="#">CAREERS</a></li>
						</ul>
						<!-- banner -->
						<div class="banner">
							<img src="http://placehold.it/150x380" alt="">
						</div>
					</div>
				</div>
				<div class="col col_w720">
					<!-- content -->
					<div class="content content_people js-content">
						<h1>The McAndrew Difference</h1>
						<h4>Our future is your future  </h4>
						<p>No matter how complex your real estate question is, we have the capabilities and expertise to deliver the right answer at the right time, so you can move forward and achieve the results you require. Welcome to McAndrew Property Group.</p>
						<p>With a qualified depth of knowledge and experience built through over 30 years in property, McAndrew’s expertise extends across all facets of residential Real Estate. 
						Whether you require Project Marketing, Property Management, Property Development, Residential Sales or Consultancy, our service is backed by a dedicated team of industry professionals committed to achieving positive outcomes for our clients. With both national and international networks, McAndrew Property Group combines global reach with the personalised approach of a proud family-owned business.</p>
						<br>
						<h4>Our Mission</h4>
						<p>At McAndrew Property Group, we understand that real relationships deliver real success. Our highly skilled team of industry professionals drive our proven track record in project delivery and sales, and are motivated to ensuring the full realisation of your vision. At McAndrew Property Group we go the extra mile to help you achieve success, because nothing is more satisfying than seeing our clients prosper through real estate. </p>
					</div>
					<!-- h -->
					<div class="h">Our Team</div>
					<!-- team -->
					<div class="team">
						<div class="team__list">
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Director and Principal</div>
							</div>
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Sales and Contracts Coordinator</div>
							</div>
							<div class="team__item">
								<div class="team__pic"></div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Director and Principal</div>
							</div>
							<div class="team__item">
								<div class="team__pic"></div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Sales and Contracts Coordinator</div>
							</div>
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Director and Principal</div>
							</div>
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Sales and Contracts Coordinator</div>
							</div>
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Director and Principal</div>
							</div>
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Sales and Contracts Coordinator</div>
							</div>
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Director and Principal</div>
							</div>
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Sales and Contracts Coordinator</div>
							</div>
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Director and Principal</div>
							</div>
							<div class="team__item">
								<div class="team__pic">
									<img src="http://placehold.it/150x150" alt="">
								</div>
								<div class="team__name">John McAndrew</div>
								<div class="team__pos">Sales and Contracts Coordinator</div>
							</div>
						</div>
					</div>
					<!-- shadow -->
					<div class="shadow"></div>
					<!-- h -->
					<div class="h">Industry Partners</div>
					<!-- partners -->
					<div class="partners">
						<ul class="partners__list">
							<li><img src="http://placehold.it/150x100" alt=""></li>
							<li><img src="http://placehold.it/150x100" alt=""></li>
							<li><img src="http://placehold.it/150x100" alt=""></li>
							<li><img src="http://placehold.it/150x100" alt=""></li>
							<li><img src="http://placehold.it/150x100" alt=""></li>
							<li><img src="http://placehold.it/150x100" alt=""></li>
							<li><img src="http://placehold.it/150x100" alt=""></li>
						</ul>
					</div>
					<!-- shadow -->
					<div class="shadow"></div>
					<!-- h -->
					<div class="h">Title</div>
					<!-- content -->
					<div class="content">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, a error repellat in repellendus maxime eum veritatis iste ex asperiores. Veniam, tempore est porro officia, deleniti non rem. Unde, natus!</p>
					</div>
					<!-- shadow -->
					<div class="shadow"></div>
					<!-- h -->
					<div class="h">Title</div>
					<!-- content -->
					<div class="content">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, a error repellat in repellendus maxime eum veritatis iste ex asperiores. Veniam, tempore est porro officia, deleniti non rem. Unde, natus!</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
