<?php
/*
Template Name: About page
*/
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
get_header(); ?>

<!-- in -->
<div class="in in_pt145">
	<!-- sl -->
	<div class="sl">
		<div class="sl__in js-sl">
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl1.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl2.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl3.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl4.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl5.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl6.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl7.jpg)"></div>
		</div>
	</div>
	<!-- center -->
	<div class="center">
		<!-- l -->
		<div class="l l_section">
			<div class="col col_w380">
				<!-- pic -->
				<div class="pic">
					<img src="http://placehold.it/380x380" alt="">
				</div>
				<!-- contacts -->
				<div class="contacts">
					<a class="contacts__item" href="tel:0732668102">
						<div class="contacts__cell">
							<i class="icon icon-phone-b"></i>
						</div>
						<div class="contacts__cell">07 3266 8102</div>
					</a>
					<a class="contacts__item" href="tel:0410481703">
						<div class="contacts__cell">
							<i class="icon icon-mob-b"></i>
						</div>
						<div class="contacts__cell">0410 481 703</div>
					</a>
					<a class="contacts__item" href="mailto:bob@google.com">
						<div class="contacts__cell">
							<i class="icon icon-mail-b"></i>
						</div>
						<div class="contacts__cell">Email Matt McAndrew</div>
					</a>
					<a class="contacts__item" href="#">
						<div class="contacts__cell">
							<i class="icon icon-in-s"></i>
						</div>
						<div class="contacts__cell">Connect with Matt McAndrew on LinkedIn</div>
					</a>
				</div>
			</div>
			<div class="col col_w490">
				<!-- content -->
				<div class="content">
					<?php
					// load content
					if (have_posts()) :
					   while (have_posts()) :
					      the_post();
					         the_content();
					   endwhile;
					endif;
					?>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
