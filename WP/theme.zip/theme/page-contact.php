<?php
/*
Template Name: Contact page
*/
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
get_header(); ?>

<!-- in -->
<div class="in">
	<!-- sl -->
	<div class="sl">
		<div class="sl__in js-sl">
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl1.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl2.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl3.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl4.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl5.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl6.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl7.jpg)"></div>
		</div>
	</div>
	<!-- center -->
	<div class="center">
		<!-- h -->
		<div class="h">Contact Us</div>
		<!-- l -->
		<div class="l l_section">
			<div class="col col_w370">
				<!-- pic -->
				<div class="pic">
					<img src="http://placehold.it/370x460" alt="">
				</div>
			</div>
			<div class="col col_w500">
				<!-- logos -->
				<div class="logos">
					<div class="logos__title"></div>
					<div class="logos__est"></div>
				</div>
				<!-- title -->
				<div class="title title_2">Head Office</div>
				<!-- contacts -->
				<div class="contacts">
					<div class="contacts__l">
						<div class="contacts__col">
							<ul class="contacts__list">
								<li>Level 1, 1163 Sandgate Road</li>
								<li>Nundah, QLD, 4012</li>
								<li>PO Box 316, Nundah QLD 4012</li>
							</ul>
						</div>
						<div class="contacts__col">
							<a class="contacts__item" href="tel:0732668102">
								<div class="contacts__cell">
									<i class="icon icon-phone-b"></i>
								</div>
								<div class="contacts__cell">07 3266 8102</div>
							</a>
							<a class="contacts__item" href="tel:0732668102">
								<div class="contacts__cell">
									<i class="icon icon-phone-big-b"></i>
								</div>
								<div class="contacts__cell">07 3266 8102</div>
							</a>
						</div>
					</div>
				</div>
				<!-- title -->
				<div class="title title_2">Send a Message</div>
				<!-- feedback -->
				<div class="feedback">
					<div class="feedback_l l">
						<div class="feedback__col">
							<!-- field -->
							<div class="field">
								<input class="input" type="text" placeholder="Name">
							</div>
							<!-- field -->
							<div class="field">
								<input class="input" type="text" placeholder="Phone">
							</div>
							<!-- field -->
							<div class="field">
								<input class="input" type="text" placeholder="Email">
							</div>
							<!-- field -->
							<div class="field">
								<textarea class="textarea" placeholder="Message"></textarea>
							</div>
							<!-- field -->
							<div class="field">
								<!-- check -->
								<label class="check">
									<input type="checkbox">
									<span class="check__in">I agree with our Privacy Statement<span class="check__link"><a href="#"><a href="#">View Privacy Statement</a></a></span></span>
								</label>
							</div>
						</div>
						<div class="feedback__col">
							<!-- title -->
							<div class="title title_3">I am interested in:</div>
							<!-- check -->
							<label class="check">
								<input type="checkbox">
								<span class="check__in">Property Management</span>
							</label>
							<!-- check -->
							<label class="check">
								<input type="checkbox">
								<span class="check__in">Residential Sales</span>
							</label>
							<!-- check -->
							<label class="check">
								<input type="checkbox">
								<span class="check__in">Development Sites</span>
							</label>
							<!-- check -->
							<label class="check">
								<input type="checkbox">
								<span class="check__in">New Development</span>
							</label>
							<!-- check -->
							<label class="check">
								<input type="checkbox">
								<span class="check__in">Receiving Newsletters</span>
							</label>
							<!-- check -->
							<label class="check">
								<input type="checkbox">
								<span class="check__in">Career Opportunities</span>
							</label>
						</div>
					</div>
					<!-- field -->
					<div class="field">
						<button class="btn">SEND</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
