head.load("<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/jquery.js", 
		  "<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/slick.min.js",
		  "<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/lightbox.min.js",
		  "<?php echo esc_url( get_template_directory_uri() ); ?>/js/common.js");
