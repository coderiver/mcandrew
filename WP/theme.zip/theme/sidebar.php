<?php
/**
 * The sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

<div class="col col_w150">
	<!-- btn-menu -->
	<button class="btn-menu js-btn-menu">
		<i></i>
		<span>Menu</span>
	</button>
	<!-- menu -->
	<ul class="menu js-menu">
		<li><a href="#">OUR MISSION</a></li>
		<li>
			<a href="#">OUR TEAM</a>
			<ul>
				<li class="is-active"><a href="#">FOR SALE</a></li>
				<li><a href="#">FOR SALE</a></li>
				<li><a href="#">FOR SALE</a></li>
			</ul>
		</li>
		<li><a href="#">INDUSTRY PARTNERS</a></li>
		<li><a href="#">OVERVIEW OF WORKING RELATIONSHIPS</a></li>
		<li><a href="#">OUR EXPERIENCE</a></li>
		<li><a href="#">CAREERS</a></li>
	</ul>
	<!-- banner -->
	<div class="banner">
		<img src="http://placehold.it/150x380" alt="">
	</div>
</div>