<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
get_header(); ?>

<!-- in -->
<div class="in">
	<!-- sl -->
	<div class="sl">
		<div class="sl__in js-sl">
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl1.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl2.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl3.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl4.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl5.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl6.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl7.jpg)"></div>
		</div>
	</div>
	<!-- center -->
	<div class="center">
		<!-- l -->
		<div class="l l_section">

			<?php get_sidebar(); ?>

			<div class="col col_w720">
				<!-- content -->
				<div class="content">
					<?php
					// load content
					if (have_posts()) :
					   while (have_posts()) :
					      the_post();
					         the_content();
					   endwhile;
					endif;
					?>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
