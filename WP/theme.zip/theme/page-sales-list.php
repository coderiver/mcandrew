<?php
/*
Template Name: Sales list page
*/
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
get_header(); ?>

<!-- in -->
<div class="in">
	<!-- sl -->
	<div class="sl">
		<div class="sl__in js-sl">
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl1.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl2.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl3.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl4.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl5.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl6.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl7.jpg)"></div>
		</div>
	</div>
	<!-- center -->
	<div class="center">
		<!-- l -->
		<div class="l l_section">
			<div class="col col_w150">
				<!-- btn-menu -->
				<button class="btn-menu js-btn-menu">
					<i></i>
					<span>Menu</span>
				</button>
				<!-- menu -->
				<ul class="menu js-menu">
					<li><a href="#">OUR MISSION</a></li>
					<li class="is-active">
						<a href="#">OUR TEAM</a>
						<ul>
							<li class="is-active"><a href="#">FOR SALE</a></li>
							<li><a href="#">FOR SALE</a></li>
							<li><a href="#">FOR SALE</a></li>
						</ul>
					</li>
					<li><a href="#">INDUSTRY PARTNERS</a></li>
					<li><a href="#">OVERVIEW OF WORKING RELATIONSHIPS</a></li>
					<li><a href="#">OUR EXPERIENCE</a></li>
					<li><a href="#">CAREERS</a></li>
				</ul>
				<!-- banner -->
				<div class="banner">
					<img src="http://placehold.it/150x380" alt="">
				</div>
			</div>
			<div class="col col_w720">
				<!-- h -->
				<div class="h"><i class="icon icon-search"></i><span>Search</span></div>
				<!-- filter -->
				<div class="filter">
					<div class="filter__row">
						<div class="filter__cell filter__cell_w310">
							<!-- field -->
							<div class="field">
								<div class="field__label">Property Type</div>
								<div class="field__in">
									<!-- select -->
									<div class="select js-select">
										<div class="select__head">All</div>
										<select name="" id="">
											<option value="All">All</option>
											<option value="Type 1">Type 1</option>
											<option value="Type 2">Type 2</option>
											<option value="Type 3">Type 3</option>
										</select>
									</div>
								</div>
							</div>
						</div>
						<div class="filter__cell filter__cell_w240">
							<!-- field -->
							<div class="field">
								<div class="field__label">Suburb</div>
								<div class="field__in">
									<!-- select -->
									<div class="select js-select">
										<div class="select__head">All</div>
										<select name="" id="">
											<option value="All">All</option>
											<option value="Type 1">Type 1</option>
											<option value="Type 2">Type 2</option>
											<option value="Type 3">Type 3</option>
										</select>
									</div>
								</div>
							</div>
						</div>
						<div class="filter__cell filter__cell_w130">
							<!-- field -->
							<div class="field">
								<div class="field__label">State</div>
								<div class="field__in">
									<!-- select -->
									<div class="select js-select">
										<div class="select__head">All</div>
										<select name="" id="">
											<option value="All">All</option>
											<option value="Type 1">Type 1</option>
											<option value="Type 2">Type 2</option>
											<option value="Type 3">Type 3</option>
										</select>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="filter__row">
						<div class="filter__cell filter__cell_w200">
							<!-- field -->
							<div class="field field_types">
								<div class="field__label">Space</div>
								<div class="field__in">
									<div class="field__cell field__cell_w60">
										<div class="field__type">
											<i class="icon icon-bed"></i>
										</div>
										<!-- select -->
										<div class="select js-select">
											<div class="select__head">All</div>
											<select name="" id="">
												<option value="All">All</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
											</select>
										</div>
									</div>
									<div class="field__cell field__cell_w60">
										<div class="field__type">
											<i class="icon icon-shower"></i>
										</div>
										<!-- select -->
										<div class="select js-select">
											<div class="select__head">All</div>
											<select name="" id="">
												<option value="All">All</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
											</select>
										</div>
									</div>
									<div class="field__cell field__cell_w60">
										<div class="field__type">
											<i class="icon icon-car"></i>
										</div>
										<!-- select -->
										<div class="select js-select">
											<div class="select__head">All</div>
											<select name="" id="">
												<option value="All">All</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
											</select>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="filter__cell filter__cell_w280">
							<!-- field -->
							<div class="field">
								<div class="field__label">Price</div>
								<div class="field__in">
									<div class="field__cell field__cell_w50p">
										<!-- select -->
										<div class="select js-select">
											<div class="select__head">Min</div>
											<select name="" id="">
												<option value="Min">Min</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
											</select>
										</div>
									</div>
									<div class="field__cell field__cell_w50p">
										<!-- select -->
										<div class="select js-select">
											<div class="select__head">Max</div>
											<select name="" id="">
												<option value="Max">Max</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
											</select>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="filter__cell filter__cell_btn">
							<button class="btn btn_big">SEARCH</button>
							<div class="filter__or">or</div>
							<button class="btn">view all</button>
						</div>
					</div>
				</div>
				<!-- h -->
				<div class="h">Residential Sales</div>
				<!-- el -->
				<div class="el el_sales">
					<div class="el__list">
						<div class="el__item">
							<div class="el__pic">
								<img src="http://placehold.it/340x190" alt="">
								<button class="btn">
									<i class="icon icon-map"></i>
								</button>
							</div>
							<!-- l -->
							<div class="l">
								<div class="el__btn">
									<button class="btn btn_small">READ MORE</button>
								</div>
								<div class="el__in">
									<!-- title -->
									<div class="title title_2">123 Address Street, Suburb</div>
									<div class="el__text">$395,000</div>
								</div>
							</div>
						</div>
						<div class="el__item">
							<div class="el__pic">
								<img src="http://placehold.it/340x190" alt="">
								<button class="btn">
									<i class="icon icon-map"></i>
								</button>
							</div>
							<!-- l -->
							<div class="l">
								<div class="el__btn">
									<button class="btn btn_small">READ MORE</button>
								</div>
								<div class="el__in">
									<!-- title -->
									<div class="title title_2">123 Address Street, Suburb</div>
									<div class="el__text">$395,000</div>
								</div>
							</div>
						</div>
						<div class="el__item">
							<div class="el__pic">
								<img src="http://placehold.it/340x190" alt="">
								<button class="btn">
									<i class="icon icon-map"></i>
								</button>
							</div>
							<!-- l -->
							<div class="l">
								<div class="el__btn">
									<button class="btn btn_small">READ MORE</button>
								</div>
								<div class="el__in">
									<!-- title -->
									<div class="title title_2">123 Address Street, Suburb</div>
									<div class="el__text">$395,000</div>
								</div>
							</div>
						</div>
						<div class="el__item">
							<div class="el__pic">
								<img src="http://placehold.it/340x190" alt="">
								<button class="btn">
									<i class="icon icon-map"></i>
								</button>
							</div>
							<!-- l -->
							<div class="l">
								<div class="el__btn">
									<button class="btn btn_small">READ MORE</button>
								</div>
								<div class="el__in">
									<!-- title -->
									<div class="title title_2">123 Address Street, Suburb</div>
									<div class="el__text">$395,000</div>
								</div>
							</div>
						</div>
						<div class="el__item">
							<div class="el__pic">
								<img src="http://placehold.it/340x190" alt="">
								<button class="btn">
									<i class="icon icon-map"></i>
								</button>
							</div>
							<!-- l -->
							<div class="l">
								<div class="el__btn">
									<button class="btn btn_small">READ MORE</button>
								</div>
								<div class="el__in">
									<!-- title -->
									<div class="title title_2">123 Address Street, Suburb</div>
									<div class="el__text">$395,000</div>
								</div>
							</div>
						</div>
						<div class="el__item">
							<div class="el__pic">
								<img src="http://placehold.it/340x190" alt="">
								<button class="btn">
									<i class="icon icon-map"></i>
								</button>
							</div>
							<!-- l -->
							<div class="l">
								<div class="el__btn">
									<button class="btn btn_small">READ MORE</button>
								</div>
								<div class="el__in">
									<!-- title -->
									<div class="title title_2">123 Address Street, Suburb</div>
									<div class="el__text">$395,000</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
