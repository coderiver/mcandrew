<?php
/*
Template Name: Sales profile page
*/
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
get_header(); ?>

<!-- in -->
<div class="in">
	<!-- sl -->
	<div class="sl">
		<div class="sl__in js-sl">
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl1.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl2.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl3.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl4.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl5.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl6.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl7.jpg)"></div>
		</div>
	</div>
	<!-- center -->
	<div class="center">
		<!-- l -->
		<div class="l l_section">
			<div class="col col_w150">
				<!-- btn-menu -->
				<button class="btn-menu js-btn-menu">
					<i></i>
					<span>Menu</span>
				</button>
				<!-- menu -->
				<ul class="menu js-menu">
					<li><a href="#">OUR MISSION</a></li>
					<li class="is-active">
						<a href="#">OUR TEAM</a>
						<ul>
							<li class="is-active"><a href="#">FOR SALE</a></li>
							<li><a href="#">FOR SALE</a></li>
							<li><a href="#">FOR SALE</a></li>
						</ul>
					</li>
					<li><a href="#">INDUSTRY PARTNERS</a></li>
					<li><a href="#">OVERVIEW OF WORKING RELATIONSHIPS</a></li>
					<li><a href="#">OUR EXPERIENCE</a></li>
					<li><a href="#">CAREERS</a></li>
				</ul>
				<!-- banner -->
				<div class="banner">
					<img src="http://placehold.it/150x380" alt="">
				</div>
			</div>
			<div class="col col_w720">
				<!-- h -->
				<div class="h">Suburb Profiles</div>
				<!-- pic -->
				<div class="pic">
					<img src="http://placehold.it/720x260" alt="">
				</div>
				<!-- l -->
				<div class="l l_section">
					<div class="col col_w470">
						<!-- content -->
						<div class="content">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.  Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.  Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia m ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
						</div>
						<!-- h -->
						<div class="h h_3">Suburbs</div>
						<!-- btn-row -->
						<div class="btn-row">
							<button class="btn btn_gray">CHERMSIDE</button>
							<button class="btn btn_gray">WEST END</button>
						</div>
					</div>
					<div class="col col_w220">
						<!-- form -->
						<div class="form form_gray">
							<div class="form__title">Register</div>
							<div class="form__text">TO RECIEVE A<br>SUBURB PROFILE</div>
							<!-- field -->
							<div class="field">
								<input class="input" type="text" placeholder="Name">
							</div>
							<!-- field -->
							<div class="field">
								<input class="input" type="text" placeholder="Email">
							</div>
							<!-- field -->
							<div class="field">
								<input class="input" type="text" placeholder="Phone">
							</div>
							<!-- field -->
							<div class="field">
								<input class="input" type="text" placeholder="Postcode">
							</div>
							<!-- field -->
							<div class="field field_mb0 field_center">
								<button class="btn">register</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
