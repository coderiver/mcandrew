<?php
/*
Template Name: Main page
*/
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
	<script>(function(){document.documentElement.className='js'})();</script>
	<?php wp_head(); ?>
</head>
<body>
	<!-- wrap -->
	<div class="wrap">
		<!-- main -->
		<div class="main">
			<div class="main__header">
				<div class="main__logo"></div>
				<nav class="main__nav">
					<?php
						$defaults = array(
							'theme_location'  => '',
							'menu'            => 'Main page menu',
							'container'       => false,
							'container_class' => '',
							'container_id'    => '',
							'menu_class'      => '',
							'menu_id'         => '',
							'echo'            => false,
							'fallback_cb'     => 'wp_page_menu',
							'before'          => '',
							'after'           => '',
							'link_before'     => '',
							'link_after'      => '',
							'items_wrap'      => '%3$s',
							'depth'           => 0,
							'walker'          => ''
						);
						echo strip_tags(wp_nav_menu($defaults), '<a>' );
						wp_nav_menu( $defaults );
					?>
				</nav>
			</div>
			<?php
				$defaults = array(
					'theme_location'  => '',
					'menu'            => 'Main page links',
					'container'       => false,
					'container_class' => '',
					'container_id'    => '',
					'menu_class'      => 'main__links',
					'menu_id'         => '',
					'echo'            => true,
					'fallback_cb'     => 'wp_page_menu',
					'before'          => '',
					'after'           => '',
					'link_before'     => '',
					'link_after'      => '',
					'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					'depth'           => 0,
					'walker'          => ''
				);
				wp_nav_menu( $defaults );
			?>
			<div class="main__slider js-sl">
				<div class="main__slide main__slide_first js-sl-item"></div>
				<div class="main__slide main__slide_second js-sl-item"></div>
				<div class="main__slide main__slide_third js-sl-item"></div>
			</div>
			<!-- est -->
			<div class="est"></div>
		</div>
		<!-- border -->
		<div class="border border_top"></div>
		<div class="border border_bottom"></div>
	</div>
	<!-- load scripts -->
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/head.js"></script>
	<script>
		head.load("<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/jquery.js", 
				  "<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/slick.min.js",
				  "<?php echo esc_url( get_template_directory_uri() ); ?>/js/lib/lightbox.min.js",
				  "<?php echo esc_url( get_template_directory_uri() ); ?>/js/common.js");
	</script>
</body>
</html>
