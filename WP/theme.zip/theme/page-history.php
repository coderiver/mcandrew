<?php
/*
Template Name: History page
*/
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
get_header(); ?>

<!-- in -->
<div class="in">
	<!-- sl -->
	<div class="sl">
		<div class="sl__in js-sl">
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl1.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl2.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl3.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl4.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl5.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl6.jpg)"></div>
			<div class="sl__item js-sl-item" style="background-image: url(<?php echo esc_url( get_template_directory_uri() ); ?>/img/sl7.jpg)"></div>
		</div>
	</div>
	<!-- center -->
	<div class="center">
		<!-- h -->
		<div class="h">Our Story</div>
		<!-- story -->
		<div class="story">
			<div class="story__list">
				<div id="eighties" class="story__item js-story">
					<div class="story__in">
						<a class="story__year js-story-go" href="#eighties">1980’s</a>
						<div class="story__l">
							<div class="story__col">
								<div class="story__title">"John McAndrew had already carved out a successful career"</div>
							</div>
							<div class="story__col">
								<!-- content -->
								<div class="content content_mb20">
									<p>By the time the McAndrew Property Group’s journey officially began in 1985, founder John McAndrew had already carved out a successful career as owner of one of Australia's leading home improvement companies. The McAndrew Property Group’s early years played out at John’s first investment property on Lutwyche Road, a $27,000 outlay that represented the first piece of what was to become an enviable investment portfolio.</p>
									<p>The property became a key part of the McAndrew story, serving as the company’s operation headquarters from 1977 until 2008 when it was subject to a compulsory resumption (at a value of $700,000 no less) by the Queensland Department of Transport. The resumption allowed for the completion of the now operational Lutwyche bus terminal.</p>
								</div>
								<!-- h -->
								<div class="h h_3 h_upper">Gallery</div>
								<!-- gallery -->
								<div class="gallery">
									<div class="gallery__list">
										<a href="http://lorempixel.com/800/600"data-lightbox="g1" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g1" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g1" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g1" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g1" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="nineties" class="story__item js-story">
					<div class="story__in">
						<a class="story__year js-story-go" href="#nineties">1990’s</a>
						<div class="story__l">
							<div class="story__col">
								<div class="story__title">"John McAndrew had already carved out a successful career"</div>
							</div>
							<div class="story__col">
								<!-- content -->
								<div class="content content_mb20">
									<p>By the time the McAndrew Property Group’s journey officially began in 1985, founder John McAndrew had already carved out a successful career as owner of one of Australia's leading home improvement companies. The McAndrew Property Group’s early years played out at John’s first investment property on Lutwyche Road, a $27,000 outlay that represented the first piece of what was to become an enviable investment portfolio.</p>
									<p>The property became a key part of the McAndrew story, serving as the company’s operation headquarters from 1977 until 2008 when it was subject to a compulsory resumption (at a value of $700,000 no less) by the Queensland Department of Transport. The resumption allowed for the completion of the now operational Lutwyche bus terminal.</p>
								</div>
								<!-- h -->
								<div class="h h_3 h_upper">Gallery</div>
								<!-- gallery -->
								<div class="gallery">
									<div class="gallery__list">
										<a href="http://lorempixel.com/800/600"data-lightbox="g2" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g2" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g2" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g2" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g2" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="noughties" class="story__item js-story">
					<div class="story__in">
						<a class="story__year js-story-go" href="#noughties">2000’s</a>
						<div class="story__l">
							<div class="story__col">
								<div class="story__title">"John McAndrew had already carved out a successful career"</div>
							</div>
							<div class="story__col">
								<!-- content -->
								<div class="content content_mb20">
									<p>By the time the McAndrew Property Group’s journey officially began in 1985, founder John McAndrew had already carved out a successful career as owner of one of Australia's leading home improvement companies. The McAndrew Property Group’s early years played out at John’s first investment property on Lutwyche Road, a $27,000 outlay that represented the first piece of what was to become an enviable investment portfolio.</p>
									<p>The property became a key part of the McAndrew story, serving as the company’s operation headquarters from 1977 until 2008 when it was subject to a compulsory resumption (at a value of $700,000 no less) by the Queensland Department of Transport. The resumption allowed for the completion of the now operational Lutwyche bus terminal.</p>
								</div>
								<!-- h -->
								<div class="h h_3 h_upper">Gallery</div>
								<!-- gallery -->
								<div class="gallery">
									<div class="gallery__list">
										<a href="http://lorempixel.com/800/600"data-lightbox="g3" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g3" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g3" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g3" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g3" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="tens" class="story__item js-story">
					<div class="story__in">
						<a class="story__year js-story-go" href="#tens">2010’s</a>
						<div class="story__l">
							<div class="story__col">
								<div class="story__title">"John McAndrew had already carved out a successful career"</div>
							</div>
							<div class="story__col">
								<!-- content -->
								<div class="content content_mb20">
									<p>By the time the McAndrew Property Group’s journey officially began in 1985, founder John McAndrew had already carved out a successful career as owner of one of Australia's leading home improvement companies. The McAndrew Property Group’s early years played out at John’s first investment property on Lutwyche Road, a $27,000 outlay that represented the first piece of what was to become an enviable investment portfolio.</p>
								</div>
								<!-- h -->
								<div class="h h_3 h_upper">Gallery</div>
								<!-- gallery -->
								<div class="gallery">
									<div class="gallery__list">
										<a href="http://lorempixel.com/800/600"data-lightbox="g4" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g4" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g4" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g4" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
										<a href="http://lorempixel.com/800/600"data-lightbox="g4" data-title="My caption"><img src="http://lorempixel.com/90/90" alt=""></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
